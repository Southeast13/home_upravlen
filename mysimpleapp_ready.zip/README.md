MySimpleApp - ready for Codemagic
=================================
Push this project to GitHub and Codemagic will build a debug APK.

Notes:
- The included './gradlew' script delegates to system 'gradle' available on Codemagic.
- If you want a full self-contained Gradle wrapper, generate it locally and push gradle/wrapper and gradlew files.
